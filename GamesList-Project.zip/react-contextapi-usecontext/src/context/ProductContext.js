import React, {createContext} from 'react'
import axios from 'axios'
import { useState } from 'react';
import { useNavigate } from 'react-router-dom'


const productContext = createContext();

export const Provider = ({children}) => {
    //tüm api işlemlerimizi gerçekleştiriyoruz.
    const navigate = useNavigate();

    const [products, setProducts] = useState([]);
    const [product, setProduct] = useState({});
  
    const getProducts = async () => {
      const response = await axios.get('https://localhost:7216/api/VideoGames');
      setProducts(response.data)
    }

    const getProduct = async (productId) => {
      const response = await axios.get(`https://localhost:7216/api/VideoGames/${productId}`)
      setProduct(response.data)
    }
  
    const postProduct = async (name, summary, genre, publisher, releaseDate, developer, platform, score) => {
      const response = await axios.post('https://localhost:7216/api/VideoGames', { 
        name,
        summary,
        genre,
        publisher,
        releaseDate,
        developer,
        platform,
        score
      });
      navigate('/products')
    }

    const updateProduct = async (updatedProduct) => {
      const response = await axios.put('https://localhost:7216/api/VideoGames',updatedProduct);
      navigate('/products')
    }

    const deleteProduct = async (productId) => {
      const response = await axios.delete(`https://localhost:7216/api/VideoGames/${productId}`)
    }

    const sharedProducts = {
        products,
        product,
        getProducts,
        postProduct,
        deleteProduct,
        getProduct,
        updateProduct
    }
    return (
        <productContext.Provider value={sharedProducts}>
            {children}
        </productContext.Provider>
    )
}

export default productContext