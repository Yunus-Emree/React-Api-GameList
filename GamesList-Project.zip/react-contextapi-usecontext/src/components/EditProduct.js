import React, {useState, useContext} from 'react'
import ProductContext from '../context/ProductContext'
import { useNavigate } from 'react-router-dom'


function CreateProduct() {

  const navigate = useNavigate();

  const {product, updateProduct} = useContext(ProductContext);

  const [name, setName] = useState(product.name)
  const [summary, setSummary] = useState(product.summary)
  const [genre, setGenre] = useState(product.genre)
  const [publisher, setPublisher] = useState(product.publisher)
  const [releaseDate, setReleaseDate] = useState(product.releaseDate)
  const [developer, setDeveloper] = useState(product.developer)
  const [platform, setPlatform] = useState(product.platform)
  const [score, setScore] = useState(product.score)

  const changeName = (event) => {
      setName(event.target.value);
  }
  const changeSummary = (event) => {
      setSummary(event.target.value);
  }
  const changeGenre = (event) => {
      setGenre(event.target.value);
  }
  const changePublisher = (event) => {
      setPublisher(event.target.value);
  }
  const changeReleaseDate = (event) => {
    setReleaseDate(event.target.value);
  }
  const changeDeveloper = (event) => {
    setDeveloper(event.target.value);
  }
  const changePlatform = (event) => {
    setPlatform(event.target.value);
  }
  const changeScore = (event) => {
    setScore(event.target.value);
  }
  const productUpdate = (event) => {
      event.preventDefault(); 
      const updatedProduct = {
        id:product.id, name, summary, genre, publisher, releaseDate, developer, platform, score
      }
      updateProduct(updatedProduct)
      navigate('/products')
  }
  return (
      <div className='col-md-4 m-auto'>
          <h4>Update Game</h4>
          <form>
              <div className="form-group">
                  <label className="form-label">Name</label>
                  <input type="text" value={name} className="form-control" onChange={changeName} />
              </div>
              <div className="form-group">
                  <label className="form-label">Summary</label>
                  <input type="text" value={summary} className="form-control"  onChange={changeSummary}/>
              </div>
              <div className="form-group">
                  <label className="form-label">Genre</label>
                  <input type="text" value={genre} className="form-control"  onChange={changeGenre}/>
              </div>
              <div className="form-group">
                  <label className="form-label">Publisher</label>
                  <input type="text" value={publisher} className="form-control"  onChange={changePublisher}/>
              </div>
              <div className="form-group">
                  <label className="form-label">ReleaseDate</label>
                  <input type="text" value={releaseDate} className="form-control"  onChange={changeReleaseDate}/>
              </div>
              <div className="form-group">
                  <label className="form-label">Developer</label>
                  <input type="text" value={developer} className="form-control"  onChange={changeDeveloper}/>
              </div>
              <div className="form-group">
                  <label className="form-label">Platform</label>
                  <input type="text" value={platform} className="form-control"  onChange={changePlatform}/>
              </div>
              <div className="form-group">
                  <label className="form-label">Score</label>
                  <input type="text" value={score} className="form-control"  onChange={changeScore}/>
              </div>
              <div className="form-group mt-3">
                  <button onClick={productUpdate} type="submit" className="btn btn-primary form-control" >Save</button>
              </div>
          </form>
          
          
     </div>
  );
}

export default CreateProduct