import React, {useContext} from 'react'
import ProductContext from '../context/ProductContext'
import { useNavigate } from 'react-router-dom';

const ProductList = () => {

  const navigate = useNavigate();

  const {products, deleteProduct, getProduct} = useContext(ProductContext);

  const onEditProduct = async (productId) => {
    await getProduct(productId)
    navigate("/editProduct")
  }

  return (
    <div className="w-75 m-auto table-responsive-md">
    <table className="table table-sm table-light mt-3 table-bordered border-dark table-striped table-hover align-middle caption-top">
    <caption>List of games</caption>
      <thead className="table-dark border-light">
        <tr>
          <th>Id</th>
          <th>Name</th>
          <th>Summary</th>
          <th>Genre</th>
          <th>Publisher</th>
          <th>Developer</th>
          <th>Release Date</th>
          <th>Platform</th>
          <th>Score</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {
          products.map((product, index) => {
              return (
              <tr key={index}>
                  <td>{product.id}</td>
                  <td>{product.name}</td>
                  <td>{product.summary}</td>
                  <td>{product.genre}</td>
                  <td>{product.publisher}</td>
                  <td>{product.developer}</td>
                  <td>{product.releaseDate}</td>
                  <td>{product.platform}</td>
                  <td>{product.score}</td>
                  <td>
                    <button className='btn btn-success my-3' onClick={() => onEditProduct(product.id)}>Edit</  button>
                    <button className='btn btn-danger' onClick={() => deleteProduct(product.id)}>Delete</button>
                  </td>
              </tr>
              );
          })
        }
      </tbody>
    </table>
  </div>
  )
}

export default ProductList