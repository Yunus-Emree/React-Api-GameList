import './App.css'
import React, {useContext, useEffect} from 'react'
import {Routes, Route} from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from './components/Home'
import CreateProduct from './components/CreateProduct'
import EditProduct from './components/EditProduct'
import ProductList from './components/ProductList'
import ProductContext from './context/ProductContext'


function App() {
  const {getProducts, products} = useContext(ProductContext);

  useEffect(() => {
    getProducts()
  
  }, [products])
  

  return (
    <div className="App">
      <div>
        <Navbar />
      </div>
      <div>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/products" element={<ProductList />} />
          <Route path="/addProduct" element={<CreateProduct />} />
          <Route path="/editProduct" element={<EditProduct />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
