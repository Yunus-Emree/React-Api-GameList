﻿using AspNetCore_React_Api.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AspNetCore_React_Api_GamesList.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VideoGamesController : ControllerBase
    {
        private readonly IVideoGameRepository _videoGameRepository;

        public VideoGamesController(IVideoGameRepository videoGameRepository)
        {
            _videoGameRepository = videoGameRepository;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var videoGames = await _videoGameRepository.GetAllAsync();
            return Ok(videoGames);
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var videoGame = await _videoGameRepository.GetByIdAsync(id);
            if (videoGame == null)
            {
                return NotFound(id);
            }
            return Ok(videoGame);
        }
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] VideoGame videoGame)
        {
            var addedVideoGame = await _videoGameRepository.CreateAsync(videoGame);
            return Created(string.Empty, addedVideoGame);
        }
        [HttpPut]
        public async Task<IActionResult> Update([FromBody] VideoGame videoGame)
        {
            var entity = await _videoGameRepository.GetByIdAsync(videoGame.Id);
            if (entity == null)
            {
                return NotFound(videoGame.Id);
            }
            await _videoGameRepository.UpdateAsync(videoGame);
            return NoContent();

        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var entity = await _videoGameRepository.GetByIdAsync(id);
            if(entity == null)
            {
                return NotFound(id);
            }
            await _videoGameRepository.DeleteAsync(entity);
            return NoContent();
        }
    }
}
