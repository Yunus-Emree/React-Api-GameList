﻿using AspNetCore_React_Api.Data;
using AspNetCore_React_Api_GamesList;
using AspNetCore_React_Api.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Linq.Expressions;

namespace AspNetCore_React_Api.Repositories
{
    public class VideoGameRepository : IVideoGameRepository
    {
        private readonly VideoGamesDbContext _context;

        public VideoGameRepository(VideoGamesDbContext context)
        {
            _context = context;
        }

        public async Task<VideoGame> CreateAsync(VideoGame videoGame)
        {
            _context.Games.AddAsync(videoGame);
            await _context.SaveChangesAsync();
            return videoGame;
        }

        public async Task DeleteAsync(VideoGame videoGame)
        {
            _context.Games.Remove(videoGame);
            await _context.SaveChangesAsync();
        }

        public async Task<List<VideoGame>> GetAllAsync()
        {
            return await _context.Games.ToListAsync();

        }

        public async Task<VideoGame> GetByIdAsync(int id)
        {
            var videoGame = await _context.Games.FindAsync(id);
            return videoGame;
        }

        public async Task UpdateAsync(VideoGame videoGame)
        {
            var orjVideoGame = await _context.Games.FirstOrDefaultAsync(c => c.Id == videoGame.Id);
            _context.Entry(orjVideoGame).CurrentValues.SetValues(videoGame);
            await _context.SaveChangesAsync();
        }
    }
}
