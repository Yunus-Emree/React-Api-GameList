﻿using AspNetCore_React_Api_GamesList;
using System.Linq.Expressions;

namespace AspNetCore_React_Api.Interfaces
{
    public interface IVideoGameRepository
    {
        Task<List<VideoGame>> GetAllAsync();
        Task<VideoGame> GetByIdAsync(int id);
        Task<VideoGame> CreateAsync(VideoGame videoGame);
        Task UpdateAsync(VideoGame videoGame);
        Task DeleteAsync(VideoGame videoGame);
    }
}
