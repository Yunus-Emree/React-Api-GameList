﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace AspNetCore_React_Api_GamesList.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Games",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Summary = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Genre = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    Publisher = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReleaseDate = table.Column<string>(type: "nvarchar(max)", nullable: false, defaultValue: "07/25/2024 19:38:32"),
                    Developer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Platform = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Score = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Games", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Games",
                columns: new[] { "Id", "Developer", "Genre", "Name", "Platform", "Publisher", "ReleaseDate", "Score", "Summary" },
                values: new object[,]
                {
                    { 1, "From Software", "Action RPG", "Elden Ring", "PC, Xbox One, PlayStation 4, Xbox Series X, PlayStation 5", "Bandai Namco Games", "25 Şubat 2022", "96", "Hidetaka Miyazaki ve George R. R. Martin Tarafından Yaratılan Yeni Bir Dünya FromSoftware, Inc. ve BANDAI NAMCO Entertainment Inc. tarafından geliştirilen ELDEN RING, etkileyici DARK SOULS video oyununun yaratıcısı Hidetaka Miyazaki tarafından yaratılan bir dünyada geçen fantastik bir aksiyon-RPG macera oyunudur." },
                    { 2, "Bandai Namco Games", "3D Fighting", "Tekken 8", "PlayStation 5, Xbox Series X, PC", "Bandai Namco Games", "26 Ocak 2024", "90", "TEKKEN 8, Mishima soyunun trajik destanına ve dünyayı sarsan baba-oğul kin maçlarına devam ediyor. Bu son destan, Jin Kazama'nın şehri sarsacak bir yüz yüze hesaplaşmada Kazuya Mishima ile karşı karşıya gelmesiyle başlıyor. Babası Heihachi Mishima'yı yendikten sonra Kazuya, dünyaya savaş açmak için G Corporation'ın güçlerini kullanarak küresel hakimiyet fethine devam ediyor. Jin, uzun süredir kayıp olan annesiyle yeniden bir araya geldiğinde kaderiyle yüzleşmek zorunda kalır ve babası Kazuya'nın terör saltanatını durdurmaya çalışır." },
                    { 3, "Larian Studios Games", "Western RPG", "Baldur's Gate 3", "PC, PlayStation 5, Xbox Series X,", "Larian Studios Games", "3 Ağustos 2023", "96", "Kadim bir kötülük Baldur Kapısı'na geri döndü ve onu içten dışa yok etme niyetindeydi. Faerun'un kaderi sizin ellerinizde. Tek başına direnebilirsin. Ancak birlikte üstesinden gelebilirsiniz. Grubunuzu toplayın ve dostluk ve ihanet, fedakarlık ve hayatta kalma ve mutlak gücün cazibesine dair bu hikayede Unutulmuş Diyarlar'a geri dönün. Beyninize yerleştirilen bir mind flayer parazitinden alınan gizemli yetenekler içinizde uyanıyor. Diren ve karanlığı kendine karşı çevir. Veya yolsuzluğu kucaklayın ve nihai kötülük haline gelin." },
                    { 4, "Santa Monica", "Action Adventure", "God of War: Ragnarok", "PlayStation 5, PlayStation 4, PC", "PlayStation Studios", "9 Kasım 2022", "94", "Geçmişteki hatalarının bilincinde olan Kratos, Atreus'u tanrılarla olan çatışmasından öğrendiği kanlı derslerden kurtarmak istiyor. Her şeyden önce oğlunu güvende tutmak istiyor ve Baldur'la yüzleşmeleri, Aesir'le daha fazla karşılaşmanın yalnızca trajedi getireceği inancını doğruladı. Kratos ve Atreus birlikte hangi yolu izleyecekleri konusunda bir seçim yapmak zorunda kalacaklar. Ragnarok yaklaşırken, seçecekleri şey Dokuz Diyar'da yaşayan herkesin kaderini belirleyecek." },
                    { 5, "Insomniac Games", "Open-World Action", "Marvel's Spider-Man 2", "Playstation 5", "Insomniac Games", "20 Ekim 2023", "90", "Spider-Man, Peter Parker ve Miles Morales, PS5 için Marvel's Spider-Man serisinde heyecan verici yeni bir macerayla geri dönüyor. Sallayın, zıplayın ve yeni Web Wings'i kullanarak Marvel'ın New York'unda seyahat edin; ikonik kötü adam Venom onların hayatlarını, şehirlerini ve sevdiklerini yok etmekle tehdit ederken farklı hikayeleri ve destansı yeni güçleri deneyimlemek için Peter Parker ve Miles Morales arasında hızla geçiş yapın. Aşk. Ortakyaşamın inanılmaz gücü, hayatlarını, dostluklarını ve ihtiyacı olanları koruma görevlerini dengelerken Peter ve Miles'ı maskenin hem içinde hem de dışında en büyük güç sınavıyla yüzleşmeye zorluyor." },
                    { 6, "CD Projekt Red Studio", "Action RPG", "Cyberpunk 2077", "PC, Xbox One, PlayStation 4, Xbox Series X, PlayStation 5", "CD Projekt Red Studio", "10 Aralık 2020", "86", "Cyberpunk 2077, güç, gösteriş ve vücut modifikasyonuna takıntılı bir mega şehir olan Night City'de geçen bir açık dünya aksiyon-macera hikayesidir. Ölümsüzlüğün anahtarı olan türünün tek örneği bir implantın peşine düşen paralı kanun kaçağı V rolünü üstlenin. Karakterinizin siber yazılımını, becerilerini ve oyun tarzını özelleştirebilir ve yaptığınız seçimlerin hikayeyi ve etrafınızdaki dünyayı şekillendirdiği geniş bir şehri keşfedebilirsiniz. Sibernetik geliştirmelerle donatılmış şehirli bir paralı asker olan bir siberpunk olun ve Night City sokaklarında efsanenizi yaratın. Hayatınızın en riskli işini üstlenin ve ölümsüzlüğün anahtarı olan prototip implantın peşine düşün." },
                    { 7, "CD Projekt Red Studio", "Action RPG", "The Witcher 3: Wild Hunt", "PC, Xbox One, PlayStation 4, Playstation 5, Xbox Series X", "CD Projekt Red Studio", "19 Mayıs 2015", "92", "İmparatorluğun Kuzey Krallıkları'na ve Vahşi Av'a saldırırken, korkunç binicilerden oluşan bir süvari alayı nefesinizi keserken hayatta kalmanın tek yolu karşılık vermektir. Usta bir kılıç ustası ve canavar avcısı olan Rivialı Geralt olarak düşmanlarınızın hiçbirini ayakta bırakmayın. Devasa bir açık dünyayı keşfedin, canavarları öldürün ve eylemlerinizle tüm toplulukların kaderini belirleyin; üstelik hepsi gerçek bir yeni nesil formatta." },
                    { 8, "Capcom", "Survival", "Resident Evil 4", "PC, Xbox One, PlayStation 4, Playstation 5, Xbox Series X", "Capcom", "24 Mart 2023", "93", "2005'in efsanevi hayatta kalma-korku oyunu Resident Evil 4, bu temelden yeniden yapımla tamamen güncel hale getirildi. Resident Evil 2 olaylarından altı yıl sonra, Raccoon City'den sağ kurtulan Leon Kennedy, ABD başkanının kızının ortadan kaybolmasını araştırmak üzere tenha bir Avrupa köyüne gönderildi. Orada keşfettiği şey, daha önce karşılaştığı hiçbir şeye benzemiyor. Modernleştirilmiş grafik ve kontrollerden, orijinal oyunun en katı hayranlarını bile şaşırtabilecek yeniden tasarlanmış bir hikayeye kadar klasik oyunun her yönü, mevcut nesil için güncellendi." },
                    { 9, "Rockstar Games", "Open-World Action", "Red Dead Redemption 2", "PC, Xbox One, PlayStation 4, Playstation 5, Xbox Series X", "Rockstar Games", "26 Ekim 2018", "97", "Grand Theft Auto V ve Red Dead Redemption'ın yaratıcıları tarafından geliştirilen Red Dead Redemption 2, Amerika'nın acımasız kalbinde geçen destansı bir yaşam öyküsüdür. Oyunun geniş ve atmosferik dünyası aynı zamanda yepyeni bir çevrimiçi çok oyunculu deneyimin temelini de sağlıyor. Amerika, 1899. Vahşi Batı döneminin sonu başladı. Batıdaki Blackwater kasabasında bir soygunun fena halde ters gitmesinin ardından Arthur Morgan ve Van der Linde çetesi kaçmak zorunda kalır. Federal ajanlar ve ülkenin en iyi ödül avcıları peşlerindeyken çetenin hayatta kalabilmek için Amerika'nın engebeli topraklarında soygun yapması, çalması ve savaşarak yol alması gerekiyor. Derinleşen iç çatlaklar çeteyi parçalamakla tehdit ederken Arthur, kendi idealleri ile onu yetiştiren çeteye olan sadakati arasında bir seçim yapmak zorundadır." }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Games");
        }
    }
}
