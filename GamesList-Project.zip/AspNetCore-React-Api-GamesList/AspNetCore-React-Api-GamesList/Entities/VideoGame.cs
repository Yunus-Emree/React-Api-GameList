﻿namespace AspNetCore_React_Api_GamesList
{
    public class VideoGame
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Summary { get; set; }
        public string Genre { get; set; }
        public string Publisher { get; set; }
        public string ReleaseDate { get; set; }
        public string Developer { get; set; }
        public string Platform { get; set; }
        public string Score { get; set; }

    }
}
